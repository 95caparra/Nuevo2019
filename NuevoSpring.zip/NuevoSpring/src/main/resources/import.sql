INSERT INTO regiones (id, nombre) VALUES (1, 'Sudamerica');
INSERT INTO regiones (id, nombre) VALUES (2, 'Centroamerica');
INSERT INTO regiones (id, nombre) VALUES (3, 'Norteamerica');
INSERT INTO regiones (id, nombre) VALUES (4, 'Europa');
INSERT INTO regiones (id, nombre) VALUES (5, 'Asia');
INSERT INTO regiones (id, nombre) VALUES (6, 'Africa');
INSERT INTO regiones (id, nombre) VALUES (7, 'Oceania');
INSERT INTO regiones (id, nombre) VALUES (8, 'Antartida');


INSERT INTO clientes (region_id, nombre, apellido, email, create_at) VALUES(1,'Andres', 'Guzman', 'profesor@bolsadeideas.com', '2017-08-01');
INSERT INTO clientes (region_id, nombre, apellido, email, create_at) VALUES(2,'John', 'Doe', 'john.doe@gmail.com', '2017-08-02');
INSERT INTO clientes (region_id, nombre, apellido, email, create_at) VALUES(3,'Linus', 'Torvalds', 'linus.torvalds@gmail.com', '2017-08-03');
INSERT INTO clientes (region_id, nombre, apellido, email, create_at) VALUES(4,'Jane', 'Doe', 'jane.doe@gmail.com', '2017-08-04');
INSERT INTO clientes (region_id, nombre, apellido, email, create_at) VALUES(5,'Rasmus', 'Lerdorf', 'rasmus.lerdorf@gmail.com', '2017-08-05');
INSERT INTO clientes (region_id, nombre, apellido, email, create_at) VALUES(6,'Erich', 'Gamma', 'erich.gamma@gmail.com', '2017-08-06');
INSERT INTO clientes (region_id, nombre, apellido, email, create_at) VALUES(7,'Richard', 'Helm', 'richard.helm@gmail.com', '2017-08-07');
INSERT INTO clientes (region_id, nombre, apellido, email, create_at) VALUES(8,'Ralph', 'Johnson', 'ralph.johnson@gmail.com', '2017-08-08');
INSERT INTO clientes (region_id, nombre, apellido, email, create_at) VALUES(1,'John', 'Vlissides', 'john.vlissides@gmail.com', '2017-08-09');
INSERT INTO clientes (region_id, nombre, apellido, email, create_at) VALUES(2,'James', 'Gosling', 'james.gosling@gmail.com', '2017-08-010');
INSERT INTO clientes (region_id, nombre, apellido, email, create_at) VALUES(3,'Bruce', 'Lee', 'bruce.lee@gmail.com', '2017-08-11');
INSERT INTO clientes (region_id, nombre, apellido, email, create_at) VALUES(4,'Johnny', 'Doe', 'johnny.doe@gmail.com', '2017-08-12');
INSERT INTO clientes (region_id, nombre, apellido, email, create_at) VALUES(5,'John', 'Roe', 'john.roe@gmail.com', '2017-08-13');
INSERT INTO clientes (region_id, nombre, apellido, email, create_at) VALUES(6,'Jane', 'Roe', 'jane.roe@gmail.com', '2017-08-14');
INSERT INTO clientes (region_id, nombre, apellido, email, create_at) VALUES(7,'Richard', 'Doe', 'richard.doe@gmail.com', '2017-08-15');
INSERT INTO clientes (region_id, nombre, apellido, email, create_at) VALUES(8,'Janie', 'Doe', 'janie.doe@gmail.com', '2017-08-16');
INSERT INTO clientes (region_id, nombre, apellido, email, create_at) VALUES(1,'Phillip', 'Webb', 'phillip.webb@gmail.com', '2017-08-17');
INSERT INTO clientes (region_id, nombre, apellido, email, create_at) VALUES(2,'Stephane', 'Nicoll', 'stephane.nicoll@gmail.com', '2017-08-18');
INSERT INTO clientes (region_id, nombre, apellido, email, create_at) VALUES(3,'Sam', 'Brannen', 'sam.brannen@gmail.com', '2017-08-19');  
INSERT INTO clientes (region_id, nombre, apellido, email, create_at) VALUES(4,'Juergen', 'Hoeller', 'juergen.Hoeller@gmail.com', '2017-08-20'); 
INSERT INTO clientes (region_id, nombre, apellido, email, create_at) VALUES(5,'Janie', 'Roe', 'janie.roe@gmail.com', '2017-08-21');
INSERT INTO clientes (region_id, nombre, apellido, email, create_at) VALUES(6,'John', 'Smith', 'john.smith@gmail.com', '2017-08-22');
INSERT INTO clientes (region_id, nombre, apellido, email, create_at) VALUES(7,'Joe', 'Bloggs', 'joe.bloggs@gmail.com', '2017-08-23');
INSERT INTO clientes (region_id, nombre, apellido, email, create_at) VALUES(8,'John', 'Stiles', 'john.stiles@gmail.com', '2017-08-24');
INSERT INTO clientes (region_id, nombre, apellido, email, create_at) VALUES(1,'Richard', 'Roe', 'stiles.roe@gmail.com', '2017-08-25');

INSERT INTO usuarios (username, password, enabled,nombre, apellido, email) VALUES ('ANDRES','$2a$10$VjjFh/SyPpJhtU3OFfoTouSWN23P2SUUFWOJctppxd8gqzk6Q8/Vi',1,'Camilo','Ochoa','95camilo.ochoa@gmail.com');
INSERT INTO usuarios (username, password, enabled,nombre, apellido, email) VALUES ('admin','$2a$10$iQAGuZhXCO9s22j9jfSKw.xARoiJu2ExpbHVta96oll8wgzNdgBey',1,'Andres','Parra','caparra95@misena.edu.co');

INSERT INTO roles (nombre) VALUES ('ROLE_USER');
INSERT INTO roles (nombre) VALUES ('ROLE_ADMIN');

INSERT INTO usuarios_roles (usuario_id, rol_id) VALUES (1,1);
INSERT INTO usuarios_roles (usuario_id, rol_id) VALUES (2,2);
INSERT INTO usuarios_roles (usuario_id, rol_id) VALUES (2,1);