package com.camilo.nuevospring.models.services;

import com.camilo.nuevospring.models.entity.Usuario;

public interface IUsuarioService {

	public Usuario findByUsername(String username);
}
