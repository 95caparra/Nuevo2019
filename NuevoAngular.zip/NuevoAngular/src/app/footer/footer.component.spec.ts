import { FooterComponent } from './footer.component';

describe('Footer.Component', () => {
  it('should create an instance', () => {
    expect(new FooterComponent()).toBeTruthy();
  });
});
